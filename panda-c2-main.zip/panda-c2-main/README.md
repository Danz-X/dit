![Panda C2 Logo](logo.jpg)
# panda-c2
#### Golang C2 Client + PHP API Handler
#### Custom design
#### PHP Handler for API
#### Golang Server Handler
```
go build -o c2
```
## Some Screens
![Panda C2 Info](info.png)
![Panda C2 Methods](methods.png)
![Panda C2 ScanPorts](scanports.png)
## Disclaimer
This repository is for academic purposes, the use of this software is your responsibility.
